# fingerprint-reader-web-extension
A Web Extension to integrate web applications with fingerprint readers.

Currently, only the folowing readers are supported:

 - Futronic FS88
 - Futronic FS88H
